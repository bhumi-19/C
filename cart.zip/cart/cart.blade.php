@include('header')
<style>
    form{
        display: inline;
    }
    .container {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 5%;
        right: 10%;
        height: 100%;
    }
</style>
<main>
    <div class="container">

        <div class="col-lg-12 mb-5 text-center   text-light  rounded  mb-2"
            style="background: url(https://cdn.pixabay.com/animation/2023/07/29/01/23/01-23-15-306_512.gif)">
            <h2>My Cart</h2>
        </div>
        {{-- @if (session('statuscart'))
            <div class="alert bg-danger text-light text-center" style="font-weight: 400;" role="alert">
                {{ session('statuscart') }}
            </div>
            <br>
        @endif --}}
        <table
            class="table table-bordered-dark text-light text-capitalize text-center   table-success-emphasis  border-light   ">

            <thead class="text-center">
                @if (session('cart') && count(session('cart')) > 0)
                    <tr>
                        <th>img</th>
                        <th>name</th>
                        <th>quantity</th>
                        <th>Price</th>
                        <th>category</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
            </thead>
            <tbody class="text-center">

                @php
                    $total = 0;
                @endphp
                @foreach (session('cart') as $k => $v)
                    @php
                        $total += $v['price'] * $v['qty'];
                    @endphp
                    <tr>
                        <td><img style="width:50px; height:50px;" src="{{ asset('upload') }}/{{ $v['pimage'] }}"
                                alt=""></td>
                        <td>{{ $v['pname'] }}</td>
                        <td>
                            <form method="post" action="{{ URL::to('/quanminus') }}">
                                @csrf
                                <button type="submit" name="sub" class="btn btn-small btn-success">-</button>
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                            </form>
                            <input name="qtty" style="background:none; border:none;" class="text-center text-light"
                                type="number" min="1" max="5" value="{{ $v['qty'] }}" disabled>
                            <form method="post" action="{{ URL::to('/quanplus') }}">
                                @csrf
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                                <button type="submit" name="add" class="btn btn-small btn-success">+</button>
                            </form>
                        </td>
                        <td>{{ $v['price'] }} ₹</td>
                        <td>{{ $v['category'] }}s</td>
                        <td>{{ $v['price'] * $v['qty'] }} ₹</td>
                        <td>
                            <form method="post" action="{{ URL::to('/deletecart') }}">
                                @csrf
                                <button type="submit" name="del" class="btn  btn-outline-danger">Remove</button>
                                <input type="hidden" name="hidid" value="{{ $v['pid'] }}">
                            </form>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    @if (session('cat'))
                        <td colspan="3">
                            <form action="{{ URL::to('/goback') }}" method="post">
                                @csrf
                                <button style="width:45%;" class="btn btn-large btn-success text-light "
                                    type="submit"><span></span>back</button>
                            </form>
                        </td>
                    @else
                        <td colspan="3"></td>
                    @endif
                    <td colspan="2">Grand Total:</td>
                    <td> {{ $total }} ₹</td>
                    <td><a class=" btn btn-outline-warning" href="{{ URL::to('/logout') }}">checkout</a></td>
                </tr>
            @else
                <tr>
                    <td colspan="7" class="text-center">
                        <h3>No Products Are There.</h3>
                    </td>
                </tr>
                @endif
            </tbody>
        </table>

    </div>
</main>
@include('footer')
