<?php

use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\Dbcontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('header', function () {
    return view('header');
});
Route::get('footer', function () {
    return view('footer');
});
Route::get('/', function () {
    return view('home');
});
Route::get('login', function () {
    return view('login');
});
Route::get('alogin', function () {
    return view('alogin');
});
Route::get('ahead', function () {
    return view('ahead');
});
Route::get('afoot', function () {
    return view('afoot');
});
Route::get('auser', function () {
    return view('auser');
});
Route::get('aproduct', function () {
    return view('aproduct');
});
Route::get('afeedback', function () {
    return view('afeedback');
});
Route::get('acategory', function () {
    return view('acategory');
});
Route::get('feedback', function () {
    return view('feedback');
});
Route::get('cart', function () {
    return view('cart');
});
Route::get('product', [Dbcontroller::class, 'product']);
Route::get('product2/{cat}', [DbController::class,'product2']);
Route::get('login', [Dbcontroller::class, 'lg']);
Route::get('alogincheck', [Dbcontroller::class, 'alogincheck']);
Route::get('auser', [Dbcontroller::class, 'auser']);
Route::post('deleteuser', [Dbcontroller::class, 'deleteuser']);
Route::get('aproduct', [Dbcontroller::class, 'aproduct']);
Route::get('afeedback', [Dbcontroller::class, 'afeedback']);
Route::get('acategory', [Dbcontroller::class, 'acategory']);
Route::post('feedback', [Dbcontroller::class, 'feedback']);
Route::post('cart', [Dbcontroller::class, 'cart']);
Route::post('quanminus', [Dbcontroller::class, 'quanminus']);
Route::post('quanplus', [Dbcontroller::class, 'quanplus']);
Route::post('deletecart', [Dbcontroller::class, 'deletecart']);

